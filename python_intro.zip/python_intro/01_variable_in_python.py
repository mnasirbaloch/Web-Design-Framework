# Integer variable declaration and initialization
num1 = 10

# Float variable declaration and initialization
num2 = 3.14

# Boolean variable declaration and initialization
is_true = True

# String variable declaration and initialization
message = "Hello, world!"

# List variable declaration and initialization
my_list = [1, 2, 3, 4, 5]

# Tuple variable declaration and initialization
my_tuple = (6, 7, 8, 9, 10)

# Dictionary variable declaration and initialization
my_dict = {'name': 'John', 'age': 30, 'city': 'New York'}

# Set variable declaration and initialization
my_set = {1, 2, 3, 4, 5}

# Printing the variables
print("num1:", num1)
print("num2:", num2)
print("is_true:", is_true)
print("message:", message)
print("my_list:", my_list)
print("my_tuple:", my_tuple)
print("my_dict:", my_dict)
print("my_set:", my_set)

